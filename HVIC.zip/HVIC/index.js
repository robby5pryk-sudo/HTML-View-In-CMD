"use strict";

const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");

const CREDITS = [
  "Created by https://github.com/robby5pryk-sudo",
  "My youtube https://www.youtube.com/@BibzS4mpwats",
];
const SPLASH_MS = 2500;

const HELP = `html-term — tampilkan & jalankan HTML langsung di terminal

Pemakaian:
  node html-term.js <file.html | https://url> [opsi]

Opsi:
  --width <px>     Lebar viewport browser (default: otomatis = 8px × jumlah kolom).
                   Isi manual, mis. 700 untuk layout mobile
  --fps <n>        Frame per detik maksimum (default 12)
  --256            Paksa mode 256 warna (jika terminal tidak mendukung truecolor)
  --no-mouse       Matikan dukungan mouse
  --no-splash      Lewati layar pembuka (credits)
  --safe-font      Ganti simbol (✦ ⌘ ⚙ ...) dengan karakter yang ada di font cmd.exe
                   (otomatis aktif di Windows kecuali Windows Terminal / VS Code)
  --no-safe-font   Matikan penggantian simbol
  --chrome <path>  Path Chrome/Edge/Chromium (atau set env CHROME_PATH)
  --once           Render satu frame lalu keluar (tanpa interaksi, bisa di-pipe)
  --plain          Dengan --once: cetak teks saja tanpa warna
  --wait <ms>      Dengan --once: tunggu sebelum capture (default 800)
  --cols <n> --rows <n>   Ukuran manual (untuk --once yang di-pipe)
  -h, --help       Bantuan

Kontrol saat berjalan:
  Ctrl+C  keluar      Ctrl+R  reload halaman     Ctrl+L  gambar ulang layar
  Ctrl+F  fokus ke kolom input pertama           Mouse   klik / scroll / hover
  Keyboard biasa (huruf, Enter, Tab, panah, PgUp/PgDn, dll) diteruskan ke halaman`;

function parseArgs(argv) {
  const o = {
    target: null, width: null, fps: 12, wait: 800, chrome: null, colors: null,
    once: false, plain: false, mouse: true, cols: null, rows: null, help: false, safe: null,
    splash: true,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const num = () => {
      const n = Number(argv[++i]);
      if (!Number.isFinite(n) || n <= 0) throw new Error(`${a} butuh angka > 0`);
      return n;
    };
    switch (a) {
      case "-h": case "--help": o.help = true; break;
      case "--once": o.once = true; break;
      case "--plain": o.plain = true; break;
      case "--256": o.colors = 256; break;
      case "--no-mouse": o.mouse = false; break;
      case "--no-splash": o.splash = false; break;
      case "--safe-font": o.safe = true; break;
      case "--no-safe-font": o.safe = false; break;
      case "--width": o.width = num(); break;
      case "--fps": o.fps = num(); break;
      case "--wait": o.wait = num(); break;
      case "--cols": o.cols = Math.floor(num()); break;
      case "--rows": o.rows = Math.floor(num()); break;
      case "--chrome": o.chrome = argv[++i]; break;
      default:
        if (a.startsWith("-")) throw new Error(`Opsi tidak dikenal: ${a}`);
        o.target = a;
    }
  }
  return o;
}

function resolveTarget(t) {
  if (/^(https?|file):\/\//i.test(t)) return t;
  const abs = path.resolve(t);
  if (!fs.existsSync(abs)) throw new Error(`File tidak ditemukan: ${abs}`);
  return pathToFileURL(abs).href;
}

function findChrome(custom) {
  const c = [custom, process.env.CHROME_PATH];
  const env = process.env;
  if (process.platform === "win32") {
    for (const r of [env.PROGRAMFILES, env["PROGRAMFILES(X86)"], env.LOCALAPPDATA].filter(Boolean)) {
      c.push(
        path.join(r, "Google", "Chrome", "Application", "chrome.exe"),
        path.join(r, "Microsoft", "Edge", "Application", "msedge.exe"),
        path.join(r, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
        path.join(r, "Chromium", "Application", "chrome.exe")
      );
    }
  } else if (process.platform === "darwin") {
    c.push(
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
      "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
      "/Applications/Chromium.app/Contents/MacOS/Chromium"
    );
  } else {
    c.push(
      "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/chromium",
      "/usr/bin/chromium-browser", "/snap/bin/chromium", "/usr/bin/microsoft-edge",
      "/usr/bin/brave-browser"
    );
  }
  return c.find((x) => x && fs.existsSync(x)) || null;
}

// Layar pembuka: gambar credits di tengah layar (tanpa menunggu).
function drawSplash() {
  const out = process.stdout;
  const cols = out.columns || 80;
  const rows = out.rows || 24;
  const top = Math.max(1, Math.floor((rows - CREDITS.length) / 2));
  let buf = "\x1b[2J";
  CREDITS.forEach((line, i) => {
    const col = Math.max(1, Math.floor((cols - line.length) / 2) + 1);
    buf += `\x1b[${top + i};${col}H\x1b[1;36m${line}\x1b[0m`;
  });
  out.write(buf);
}

const lin = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
const lum = (c) => 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]);
const contrast = (a, b) => {
  const x = lum(a), y = lum(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
};
const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

function ensureContrast(fg, bg, min = 3) {
  if (contrast(fg, bg) >= min) return fg;
  const target = lum(bg) > 0.179 ? [0, 0, 0] : [255, 255, 255];
  for (let t = 0.1; t <= 1.001; t += 0.1) {
    const c = mix(fg, target, t);
    if (contrast(c, bg) >= min) return c;
  }
  return target;
}

function to256(c) {
  const [r, g, b] = c;
  if (Math.abs(r - g) < 8 && Math.abs(g - b) < 8) {
    if (r < 8) return 16;
    if (r > 248) return 231;
    return Math.round(((r - 8) / 247) * 24) + 232;
  }
  const q = (v) => Math.round((v / 255) * 5);
  return 16 + 36 * q(r) + 6 * q(g) + q(b);
}

function charWidth(cp) {
  if (cp < 32 || (cp >= 0x7f && cp < 0xa0)) return 0;
  if ((cp >= 0x300 && cp <= 0x36f) || cp === 0x200b || cp === 0x200d || (cp >= 0xfe00 && cp <= 0xfe0f)) return 0;
  if (
    (cp >= 0x1100 && cp <= 0x115f) || (cp >= 0x2e80 && cp <= 0xa4cf) || (cp >= 0xac00 && cp <= 0xd7a3) ||
    (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xfe30 && cp <= 0xfe6f) || (cp >= 0xff00 && cp <= 0xff60) ||
    (cp >= 0xffe0 && cp <= 0xffe6) || (cp >= 0x1f300 && cp <= 0x1faff) || (cp >= 0x20000 && cp <= 0x3fffd)
  ) return 2;
  return 1;
}

const SAFE_MAP = {
  "✦": "♦", "✧": "◊", "⌘": "¤", "◈": "◊", "⌁": "≈", "⌕": "○", "⚙": "☼", "☰": "≡", "◫": "□", "◉": "●",
  "★": "*", "☆": "*", "✓": "√", "✔": "√", "✕": "×", "✖": "×", "✘": "×", "❯": ">", "❮": "<",
  "➜": "→", "➤": "►", "▸": "►", "▾": "▼", "▴": "▲", "⋯": "…",
};
function safeGlyph(g) {
  const cp = g.codePointAt(0);
  if (cp < 0x2000) return g;
  if (SAFE_MAP[g]) return SAFE_MAP[g];
  if (cp >= 0x1f000) return "•"; // emoji
  return g;
}

function extractInPage() {
  const SKIP = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "OPTION", "TITLE", "HEAD"]);
  const vw = window.innerWidth, vh = window.innerHeight;
  const out = { title: document.title, words: [], inputs: [] };
  const cache = new Map();

  const parseColor = (s) => {
    if (!s) return null;
    const m = s.match(/[\d.]+/g);
    if (!m) return null;
    let n = m.map(Number);
    if (/^color\(/.test(s)) n = n.map((x, i) => (i < 3 ? x * 255 : x));
    return [n[0] | 0, n[1] | 0, n[2] | 0, n.length > 3 ? n[3] : 1];
  };

  const info = (el) => {
    let v = cache.get(el);
    if (v) return v;
    const cs = getComputedStyle(el);
    const p = el.parentElement ? info(el.parentElement) : null;
    const op = cs.opacity === "" ? 1 : parseFloat(cs.opacity);
    v = {
      op: (p ? p.op : 1) * (Number.isNaN(op) ? 1 : op),
      hidden: cs.visibility !== "visible",
      color: parseColor(cs.color),
      bold: (parseInt(cs.fontWeight, 10) || 400) >= 600,
      ul: (cs.textDecorationLine || "").indexOf("underline") >= 0,
      tt: cs.textTransform,
      fs: parseFloat(cs.fontSize) || 13,
      nw: /^(nowrap|pre)$/.test(cs.whiteSpace),
    };
    cache.set(el, v);
    return v;
  };

  // tepi kanan kotak (block) tempat teks berada -> batas pembungkusan baris
  const brCache = new Map();
  const blockRight = (el) => {
    if (brCache.has(el)) return brCache.get(el);
    let b = el;
    while (b.parentElement && /^inline/.test(getComputedStyle(b).display)) b = b.parentElement;
    const cs = getComputedStyle(b);
    const v = b.getBoundingClientRect().right - (parseFloat(cs.paddingRight) || 0) - (parseFloat(cs.borderRightWidth) || 0);
    brCache.set(el, v);
    return v;
  };

  const transform = (t, tt) =>
    tt === "uppercase" ? t.toUpperCase()
    : tt === "lowercase" ? t.toLowerCase()
    : tt === "capitalize" ? t.charAt(0).toUpperCase() + t.slice(1)
    : t;

  const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
  const range = document.createRange();
  let node, nid = 0;
  while ((node = walker.nextNode())) {
    nid++;
    const el = node.parentElement;
    if (!el || SKIP.has(el.tagName) || !node.data.trim()) continue;
    const inf = info(el);
    if (inf.hidden || inf.op < 0.05) continue;
    const re = /\S+/g;
    let m;
    while ((m = re.exec(node.data))) {
      range.setStart(node, m.index);
      range.setEnd(node, m.index + m[0].length);
      const r = range.getClientRects()[0];
      if (!r || r.width === 0 || r.height === 0) continue;
      if (r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw) continue;
      const cx = Math.min(vw - 1, Math.max(0, r.left + r.width / 2));
      const cy = Math.min(vh - 1, Math.max(0, r.top + r.height / 2));
      const top = document.elementFromPoint(cx, cy);
      if (!top || !(top === el || el.contains(top) || top.contains(el))) continue; // tertutup / terpotong
      out.words.push({
        t: transform(m[0], inf.tt), x: r.left, y: r.top, w: r.width, h: r.height,
        c: inf.color, o: inf.op, b: inf.bold, u: inf.ul, fs: inf.fs,
        nid, br: blockRight(el), nw: inf.nw,
      });
    }
  }

  const OK = ["text", "search", "email", "url", "tel", "password", "number", ""];
  for (const el of document.querySelectorAll("input, textarea")) {
    const type = (el.type || "text").toLowerCase();
    if (el.tagName === "INPUT" && OK.indexOf(type) < 0) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1 || r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility !== "visible" || cs.display === "none") continue;
    const val = type === "password" ? "•".repeat(el.value.length) : el.value;
    const ph = !val && !!el.placeholder;
    let caret = null;
    try { caret = el.selectionStart; } catch (e) { /* tipe input tanpa selection */ }
    const f = (p) => parseFloat(cs[p]) || 0;
    const padL = f("paddingLeft") + f("borderLeftWidth"), padR = f("paddingRight") + f("borderRightWidth");
    const padT = f("paddingTop") + f("borderTopWidth"), padB = f("paddingBottom") + f("borderBottomWidth");
    out.inputs.push({
      text: ph ? el.placeholder : val, ph, multi: el.tagName === "TEXTAREA",
      x: r.left + padL, y: r.top + padT, w: r.width - padL - padR,
      bottom: r.bottom - padB, cy: (r.top + r.bottom) / 2,
      lh: parseFloat(cs.lineHeight) || (parseFloat(cs.fontSize) || 13) * 1.3,
      color: parseColor(ph ? getComputedStyle(el, "::placeholder").color : cs.color),
      focused: document.activeElement === el, caret,
    });
  }
  return out;
}

const HIDE_TEXT_CSS = `
  *, *::before, *::after { -webkit-text-fill-color: transparent !important; text-shadow: none !important;
    -webkit-text-stroke: 0 !important; text-decoration-color: transparent !important; caret-color: transparent !important; }
  *::placeholder { -webkit-text-fill-color: transparent !important; }
  ::-webkit-scrollbar { display: none !important; }
  html { scrollbar-width: none !important; }
`;

function layoutInput(text, width) {
  const lines = [];
  let idx = 0;
  for (const seg of text.split("\n")) {
    if (seg.length === 0) lines.push({ s: "", start: idx });
    else for (let i = 0; i < seg.length; i += width) lines.push({ s: seg.slice(i, i + width), start: idx + i });
    idx += seg.length + 1;
  }
  return lines;
}

function reflowWords(words, geo, cellLen) {
  const { pxCol, pxRow, cols } = geo;
  const asItem = (w) => ({ ...w, row: Math.floor((w.y + w.h / 2) / pxRow), col: Math.round(w.x / pxCol), cy: w.y + w.h / 2 });
  const groups = new Map();
  for (const w of words) {
    if (!groups.has(w.nid)) groups.set(w.nid, []);
    groups.get(w.nid).push(w);
  }
  const out = [];
  for (const ws of groups.values()) {
    if (ws.length < 2 || ws[0].nw) { for (const w of ws) out.push(asItem(w)); continue; }
    ws.sort((a, b) => a.y - b.y || a.x - b.x);
    const lines = [];
    for (const w of ws) {
      const ln = lines[lines.length - 1];
      if (ln && Math.abs(w.y - ln.y) < w.h * 0.5) ln.words.push(w);
      else lines.push({ y: w.y, h: w.h, words: [w] });
    }
    if (lines.length < 2) { for (const w of ws) out.push(asItem(w)); continue; }
    const boxR = Math.min(cols, Math.floor(ws[0].br / pxCol));
    const L0 = Math.round(Math.min(...ws.map((w) => w.x)) / pxCol);
    let overflow = false;
    for (const ln of lines) {
      let last = -2;
      for (const w of ln.words) {
        const c = Math.max(Math.round(w.x / pxCol), last + 2);
        last = c + cellLen(w) - 1;
      }
      if (last > boxR) overflow = true;
    }
    if (!overflow) { for (const w of ws) out.push(asItem(w)); continue; }

    const gaps = [];
    for (let i = 1; i < lines.length; i++) gaps.push(lines[i].y - lines[i - 1].y);
    const m = Math.max(1, Math.min(...gaps)); // jarak baris normal (px)
    const paras = [[lines[0]]];
    for (let i = 1; i < lines.length; i++) {
      if (gaps[i - 1] > m * 1.6) paras.push([lines[i]]);
      else paras[paras.length - 1].push(lines[i]);
    }

    const width = Math.max(8, boxR - L0);
    let curRow = -1e9;
    for (const para of paras) {
      const flat = para.flatMap((l) => l.words);
      let row = Math.max(Math.floor((para[0].y + para[0].h / 2) / pxRow), curRow + 1);
      const firstRow = row;
      let k = 0, cursor = 0;
      for (const w of flat) {
        const len = cellLen(w);
        if (cursor > 0 && cursor + 1 + len > width) {
          k++; cursor = 0;
          row = Math.max(row + 1, firstRow + Math.round((k * m) / pxRow));
        }
        const col = L0 + cursor + (cursor > 0 ? 1 : 0);
        out.push({ ...w, row, col, x: col * pxCol, cy: row * pxRow + pxRow / 2, fixed: true });
        cursor += (cursor > 0 ? 1 : 0) + len;
      }
      curRow = row;
    }
  }
  return out;
}

function compose(pix, data, geo, mode) {
  const { cols, rows, W, pxCol, pxRow } = geo;
  const n = cols * rows;
  const ch = new Array(n).fill(null); // null = sel kosong, "" = lanjutan karakter lebar
  const sty = new Array(n).fill(null);

  const put = (r, c, g, style) => {
    const w = charWidth(g.codePointAt(0));
    if (w === 0 || r < 0 || r >= rows || c < 0 || c + w > cols) return 0;
    ch[r * cols + c] = g;
    sty[r * cols + c] = style;
    if (w === 2) ch[r * cols + c + 1] = "";
    return w;
  };

  const mapG = mode.safe ? safeGlyph : (g) => g;
  const stepOf = (fs) => Math.min(3, Math.max(1, Math.floor((geo.advEm * fs) / pxCol + 0.25)));
  const cellLen = (w) => Array.from(w.t).reduce((n, g) => n + (charWidth(mapG(g).codePointAt(0)) || 0), 0) * stepOf(w.fs);
  const items = reflowWords(data.words, geo, cellLen);
  {
    const loose = items.filter((i) => !i.fixed).sort((a, b) => a.cy - b.cy);
    let anchor = null;
    for (const it of loose) {
      if (anchor && Math.abs(it.cy - anchor.cy) < Math.min(it.h, anchor.h) * 0.5) { it.row = anchor.row; it.cy = anchor.cy; }
      else anchor = it;
    }
  }
  items.sort((a, b) => a.row - b.row || a.x - b.x);
  const last = new Array(rows).fill(-2);
  const claim = new Array(rows).fill(null);
  const sameLine = (r, cy) => claim[r] === null || Math.abs(cy - claim[r]) <= pxRow * 0.75;
  for (const it of items) {
    let r = it.row;
    if (r < 0 || r >= rows) continue;
    if (!sameLine(r, it.cy)) {
      if (r + 1 < rows && sameLine(r + 1, it.cy)) r++;
      else continue;
    }
    if (claim[r] === null) claim[r] = it.cy;
    let c = Math.max(it.col, last[r] + 2);
    const style = { c: it.c, o: it.o, b: it.b, u: it.u };
    // teks besar (judul) direnggangkan agar lebarnya mendekati aslinya
    const step = stepOf(it.fs);
    for (const g0 of Array.from(it.t)) {
      const g = mapG(g0);
      const gw = charWidth(g.codePointAt(0));
      if (gw === 0) continue;
      if (c + gw > cols) { put(r, cols - 1, "…", style); c = cols; break; }
      put(r, c, g, style);
      c += Math.max(gw, step);
    }
    last[r] = Math.min(cols - 1, c - step);
  }

  const caretCells = [];
  for (const inp of data.inputs) {
    const wCells = Math.max(1, Math.floor(inp.w / pxCol));
    const c0 = Math.round(inp.x / pxCol);
    const style = { c: inp.color, o: 1, b: false, u: false };
    const caret = inp.caret == null ? inp.text.length : inp.caret;
    const row0 = inp.multi
      ? Math.floor((inp.y + inp.lh / 2) / pxRow)
      : Math.floor(inp.cy / pxRow);
    let shown; // [{s, caretCol|null}]
    if (!inp.multi) {
      const start = inp.focused ? Math.max(0, caret - wCells + 1) : 0;
      const s = inp.text.slice(start, start + wCells);
      shown = [{ s, row: row0, caretCol: inp.focused ? caret - start : null }];
    } else {
      const lines = layoutInput(inp.text, wCells);
      const rowMax = Math.floor((inp.bottom - 1) / pxRow);
      const maxLines = Math.max(1, rowMax - row0 + 1);
      let cl = 0;
      lines.forEach((l, i) => { if (l.start <= caret) cl = i; });
      let first = 0;
      if (lines.length > maxLines && inp.focused) first = Math.min(Math.max(0, cl - maxLines + 1), lines.length - maxLines);
      shown = [];
      let prev = row0 - 1;
      for (let j = first; j < Math.min(lines.length, first + maxLines); j++) {
        const r = Math.max(prev + 1, Math.floor((inp.y + (j - first) * inp.lh + inp.lh / 2) / pxRow));
        prev = r;
        shown.push({ s: lines[j].s, row: r, caretCol: inp.focused && j === cl ? Math.min(caret - lines[j].start, wCells - 1) : null });
      }
    }
    for (const ln of shown) {
      let c = c0;
      for (const g of ln.s) c += put(ln.row, c, mapG(g), style) || 0;
      if (ln.caretCol != null && ln.row >= 0 && ln.row < rows) caretCells.push([ln.row, c0 + ln.caretCol]);
    }
  }

  const trueColor = mode.colors !== 256;
  const sgrFg = (c) => (trueColor ? `38;2;${c[0]};${c[1]};${c[2]}` : `38;5;${to256(c)}`);
  const sgrBg = (c) => (trueColor ? `48;2;${c[0]};${c[1]};${c[2]}` : `48;5;${to256(c)}`);
  const px = (y, x) => {
    const i = (y * W + x) * 3;
    return [pix[i] & 0xfc, pix[i + 1] & 0xfc, pix[i + 2] & 0xfc];
  };
  const caretSet = new Set(caretCells.map(([r, c]) => r * cols + c));

  const lines = [];
  for (let r = 0; r < rows; r++) {
    let s = "", cf = "", cb = "", bold = false, ul = false;
    let plain = "";
    for (let c = 0; c < cols; c++) {
      const i = r * cols + c;
      const g = ch[i];
      if (g === "") continue;
      const top = px(2 * r, c), bot = px(2 * r + 1, c);
      let out, fg = null, bg, wantBold = false, wantUl = false;
      const isCaret = caretSet.has(i);

      if (g === null && !isCaret) {
        if (top[0] === bot[0] && top[1] === bot[1] && top[2] === bot[2]) { out = " "; bg = top; }
        else { out = "▀"; fg = top; bg = bot; }
        plain += " ";
      } else {
        const st = sty[i];
        bg = mix(top, bot, 0.5);
        if (g === null || isCaret) {
          out = g === null ? " " : g;
          fg = [8, 8, 16]; bg = [235, 235, 250];
        } else {
          out = g;
          if (!st.c || st.c[3] * st.o < 0.05) fg = lum(bg) > 0.179 ? [0, 0, 0] : [255, 255, 255];
          else fg = ensureContrast(mix(bg, st.c, Math.min(1, st.c[3] * st.o)), bg, 3);
          wantBold = st.b; wantUl = st.u;
        }
        plain += g === null ? " " : g;
      }

      if (!mode.plain) {
        const nf = fg ? sgrFg(fg.map(Math.round)) : cf;
        const nb = sgrBg(bg.map(Math.round));
        const codes = [];
        if (wantBold !== bold) { codes.push(wantBold ? "1" : "22"); bold = wantBold; }
        if (wantUl !== ul) { codes.push(wantUl ? "4" : "24"); ul = wantUl; }
        if (nf !== cf) { codes.push(nf); cf = nf; }
        if (nb !== cb) { codes.push(nb); cb = nb; }
        if (codes.length) s += `\x1b[${codes.join(";")}m`;
        s += out;
      }
    }
    lines.push(mode.plain ? plain.replace(/\s+$/, "") : s + "\x1b[0m");
  }
  return lines;
}

function makeInputParser() {
  let pasteBuf = null;
  return function parse(str) {
    const ev = [];
    let i = 0;
    while (i < str.length) {
      if (pasteBuf !== null) {
        const end = str.indexOf("\x1b[201~", i);
        if (end < 0) { pasteBuf += str.slice(i); i = str.length; }
        else { pasteBuf += str.slice(i, end); ev.push({ type: "paste", text: pasteBuf }); pasteBuf = null; i = end + 6; }
        continue;
      }
      const rest = str.slice(i);
      let m;
      if (rest.startsWith("\x1b[200~")) { pasteBuf = ""; i += 6; continue; }
      if ((m = /^\x1b\[<(\d+);(\d+);(\d+)([Mm])/.exec(rest))) {
        ev.push({ type: "mouse", b: +m[1], x: +m[2], y: +m[3], down: m[4] === "M" });
        i += m[0].length; continue;
      }
      if ((m = /^\x1b\[([0-9;]*)([A-Za-z~])/.exec(rest)) || (m = /^\x1bO()([A-Za-z])/.exec(rest))) {
        const [, p, f] = m;
        const first = p.split(";")[0];
        let key = null;
        if (f === "A") key = "ArrowUp"; else if (f === "B") key = "ArrowDown";
        else if (f === "C") key = "ArrowRight"; else if (f === "D") key = "ArrowLeft";
        else if (f === "H") key = "Home"; else if (f === "F") key = "End";
        else if (f === "Z") key = "ShiftTab";
        else if (f === "~") key = { 1: "Home", 2: "Insert", 3: "Delete", 4: "End", 5: "PageUp", 6: "PageDown", 7: "Home", 8: "End" }[first] || null;
        if (key) ev.push({ type: "key", key });
        i += m[0].length; continue;
      }
      const cp = rest.codePointAt(0);
      const chr = String.fromCodePoint(cp);
      i += chr.length;
      if (chr === "\x1b") ev.push({ type: "key", key: "Escape" });
      else if (chr === "\r" || chr === "\n") ev.push({ type: "key", key: "Enter" });
      else if (chr === "\t") ev.push({ type: "key", key: "Tab" });
      else if (chr === "\x7f" || chr === "\b") ev.push({ type: "key", key: "Backspace" });
      else if (chr === "\x03") ev.push({ type: "action", name: "quit" });
      else if (chr === "\x12") ev.push({ type: "action", name: "reload" });
      else if (chr === "\x0c") ev.push({ type: "action", name: "redraw" });
      else if (chr === "\x06") ev.push({ type: "action", name: "focus" });
      else if (cp >= 1 && cp <= 26) ev.push({ type: "chord", key: String.fromCharCode(96 + cp) });
      else if (cp >= 32) {
        const lastEv = ev[ev.length - 1];
        if (lastEv && lastEv.type === "text") lastEv.text += chr;
        else ev.push({ type: "text", text: chr });
      }
    }
    return ev;
  };
}

async function main() {
  let opts;
  try { opts = parseArgs(process.argv.slice(2)); }
  catch (e) { console.error(`Error: ${e.message}\n`); console.error(HELP); process.exit(2); }
  if (opts.help || !opts.target) { console.log(HELP); process.exit(opts.help ? 0 : 2); }

  const out = process.stdout;
  const interactive = !opts.once;
  if (interactive && !(process.stdin.isTTY && out.isTTY)) {
    console.error("Error: mode interaktif butuh terminal (TTY). Gunakan --once untuk output satu frame.");
    process.exit(2);
  }

  let url;
  try { url = resolveTarget(opts.target); } catch (e) { console.error(`Error: ${e.message}`); process.exit(1); }

  const executablePath = findChrome(opts.chrome);
  if (!executablePath) {
    console.error("Error: Chrome/Edge/Chromium tidak ditemukan.\nInstal salah satunya, atau set env CHROME_PATH / gunakan --chrome <path>.");
    process.exit(1);
  }

  if (opts.safe === null) {
    opts.safe = process.platform === "win32" && !process.env.WT_SESSION && process.env.TERM_PROGRAM !== "vscode";
  }
  if (!opts.colors) {
    const ct = (process.env.COLORTERM || "").toLowerCase();
    const trueOk = ct.includes("truecolor") || ct.includes("24bit") || process.env.WT_SESSION || process.env.TERM_PROGRAM || process.platform === "win32" || opts.once;
    opts.colors = trueOk ? 16777216 : 256;
  }

  // Muat modul dulu; jika gagal, terminal belum diubah sama sekali.
  const puppeteer = require("puppeteer-core");
  const sharp = require("sharp");

  // Splash: tampil selagi Chrome dijalankan dan halaman dimuat.
  let splashAt = 0;
  if (opts.splash) {
    if (interactive) {
      out.write("\x1b[?1049h\x1b[?25l");
      drawSplash();
      splashAt = Date.now();
    } else if (!opts.plain) {
      // mode --once: ke stderr agar output yang di-pipe tetap bersih
      console.error(CREDITS.join("\n"));
    }
  }

  const args = ["--hide-scrollbars", "--force-color-profile=srgb", "--font-render-hinting=none", "--disable-dev-shm-usage"];
  if (typeof process.getuid === "function" && process.getuid() === 0) args.push("--no-sandbox");

  let browser;
  try {
    browser = await puppeteer.launch({ executablePath, headless: true, args, defaultViewport: null });
  } catch (e) {
    if (splashAt) out.write("\x1b[0m\x1b[?25h\x1b[?1049l");
    console.error(`Error: gagal menjalankan browser (${executablePath})\n${e.message}`);
    process.exit(1);
  }
  const page = await browser.newPage();
  await page.setBypassCSP(true);

  let geo;
  const metrics = { advEm: 0.55 };
  const computeGeo = () => {
    const cols = opts.cols || out.columns || 120;
    const totalRows = opts.rows || out.rows || 40;
    const rows = interactive ? Math.max(4, totalRows - 1) : totalRows; // 1 baris untuk status bar
    // Lebar viewport otomatis: 8px CSS per kolom (1 sel = 8x16px). Desain web biasanya memakai
    // kelipatan 8px, sehingga jarak antar baris jadi rata di grid terminal.
    const vw = opts.width || Math.min(1700, Math.max(900, cols * 8));
    const vh = Math.max(100, Math.round((vw * rows * 2) / cols));
    return { cols, rows, W: cols, H: rows * 2, vw, vh, pxCol: vw / cols, pxRow: vh / rows, advEm: metrics.advEm };
  };
  geo = computeGeo();
  await page.setViewport({ width: geo.vw, height: geo.vh, deviceScaleFactor: 1 });

  let statusMsg = { text: "", until: 0 };
  const flash = (text, ms = 4000) => { statusMsg = { text: String(text).replace(/\s+/g, " ").slice(0, 200), until: Date.now() + ms }; };
  const injectCss = () => page.addStyleTag({ content: HIDE_TEXT_CSS }).catch(() => {});
  page.on("domcontentloaded", injectCss);
  page.on("dialog", async (d) => { flash(`[${d.type()}] ${d.message()}`, 6000); try { await d.accept(d.defaultValue()); } catch (e) { /* abaikan */ } });
  page.on("pageerror", (e) => flash(`[error] ${e.message}`, 8000));
  page.on("console", (m) => flash(`[console.${m.type()}] ${m.text()}`, 5000));

  try { await page.goto(url, { waitUntil: "load", timeout: 30000 }); }
  catch (e) { flash(`Gagal memuat: ${e.message}`, 8000); }
  await injectCss();

  const measure = async () => {
    try {
      const d = await page.evaluate(extractInPage);
      const ws = d.words.filter((w) => Array.from(w.t).length >= 4 && w.fs >= 8 && w.fs <= 28);
      if (ws.length < 3) return;
      const adv = ws.map((w) => w.w / Array.from(w.t).length / w.fs).sort((a, b) => a - b);
      metrics.advEm = Math.min(0.75, Math.max(0.4, adv[adv.length >> 1]));
    } catch (e) { /* pakai default */ }
  };
  await measure();
  geo = computeGeo();
  await page.setViewport({ width: geo.vw, height: geo.vh, deviceScaleFactor: 1 });
  await new Promise((r) => setTimeout(r, 150)); // beri waktu layout responsif menyesuaikan
  if (process.env.HTML_TERM_DEBUG) console.error("[debug]", JSON.stringify({ metrics, geo: { cols: geo.cols, rows: geo.rows, vw: geo.vw, vh: geo.vh, pxCol: +geo.pxCol.toFixed(2) } }));

  const grab = async () => {
    const [shot, data] = await Promise.all([
      page.screenshot({ type: "jpeg", quality: 70, optimizeForSpeed: true }),
      page.evaluate(extractInPage),
    ]);
    const pix = await sharp(shot).resize(geo.W, geo.H, { fit: "fill", kernel: "mitchell" }).removeAlpha().raw().toBuffer();
    return { lines: compose(pix, data, geo, { colors: opts.colors, plain: opts.plain, safe: opts.safe }), title: data.title };
  };

  if (!interactive) {
    await new Promise((r) => setTimeout(r, opts.wait));
    const f = await grab();
    out.write(f.lines.join("\n") + "\n");
    if (opts.plain) console.error(`[title] ${f.title}`);
    await browser.close();
    process.exit(0);
  }

  // Pastikan splash tampil minimal SPLASH_MS sejak pertama digambar.
  if (splashAt) {
    const remain = SPLASH_MS - (Date.now() - splashAt);
    if (remain > 0) await new Promise((r) => setTimeout(r, remain));
  }

  let running = true, closing = false;
  const W = (s) => out.write(s);

  const restore = () => {
    W("\x1b[0m\x1b[?7h\x1b[?1003l\x1b[?1006l\x1b[?1000l\x1b[?2004l\x1b[?25h\x1b[?1049l");
    try { process.stdin.setRawMode(false); } catch (e) { /* abaikan */ }
  };
  const shutdown = async (code = 0) => {
    if (closing) return;
    closing = true; running = false;
    restore();
    try { await Promise.race([browser.close(), new Promise((r) => setTimeout(r, 2000))]); } catch (e) { /* abaikan */ }
    process.exit(code);
  };
  process.on("exit", restore);
  process.on("SIGINT", () => shutdown(0));
  process.on("SIGTERM", () => shutdown(0));
  process.on("SIGHUP", () => shutdown(0));
  process.on("uncaughtException", (e) => { restore(); console.error(e); process.exit(1); });
  browser.on("disconnected", () => shutdown(0));

  // Alternate screen: masuk hanya jika belum dimasuki oleh splash.
  W((splashAt ? "" : "\x1b[?1049h") + "\x1b[?25l\x1b[?7l\x1b[2J\x1b[?2004h"); // ?7l = matikan auto-wrap agar tidak ada scroll tak sengaja
  if (opts.mouse) W("\x1b[?1000h\x1b[?1003h\x1b[?1006h");
  process.stdin.setRawMode(true);
  process.stdin.setEncoding("utf8");
  process.stdin.resume();

  let prev = [];
  let title = "";
  const present = (lines) => {
    let buf = "";
    lines.forEach((s, i) => { if (prev[i] !== s) { buf += `\x1b[${i + 1};1H${s}`; prev[i] = s; } });
    // status bar
    const msg = Date.now() < statusMsg.until ? statusMsg.text : `${title || opts.target}  │  Ctrl+C keluar · Ctrl+R reload · Ctrl+F fokus input · mouse aktif`;
    const cols = geo.cols;
    let line = ` ${msg}`;
    if (line.length > cols - 1) line = line.slice(0, cols - 2) + "…";
    line = line.padEnd(cols - 1, " "); // sisakan kolom terakhir kosong (hindari scroll di console lama)
    const sk = `\x1b[${geo.rows + 1};1H\x1b[0m\x1b[7m${line}\x1b[0m`;
    if (prev.status !== sk) { buf += sk; prev.status = sk; }
    if (buf) W("\x1b[?2026h" + buf + "\x1b[?2026l");
  };

  let wakeFn = null;
  const wake = () => { if (wakeFn) wakeFn(); };
  const sleepOrWake = (ms) => new Promise((res) => {
    const done = () => { clearTimeout(t); wakeFn = null; res(); };
    const t = setTimeout(done, ms);
    wakeFn = done;
  });

  let resizeTimer = null;
  out.on("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(async () => {
      geo = computeGeo();
      try { await page.setViewport({ width: geo.vw, height: geo.vh, deviceScaleFactor: 1 }); } catch (e) { /* abaikan */ }
      prev = [];
      W("\x1b[2J");
      wake();
    }, 120);
  });

  const parse = makeInputParser();
  let queue = Promise.resolve();
  let lastMove = "";
  const handle = async (ev) => {
    switch (ev.type) {
      case "text": await page.keyboard.type(ev.text); break;
      case "paste": await page.keyboard.sendCharacter(ev.text); break;
      case "key":
        if (ev.key === "ShiftTab") { await page.keyboard.down("Shift"); await page.keyboard.press("Tab"); await page.keyboard.up("Shift"); }
        else await page.keyboard.press(ev.key);
        break;
      case "chord":
        await page.keyboard.down("Control"); await page.keyboard.press(ev.key); await page.keyboard.up("Control");
        break;
      case "action":
        if (ev.name === "quit") await shutdown(0);
        else if (ev.name === "reload") { flash("Reload…", 1500); await page.reload({ waitUntil: "load" }).catch(() => {}); await injectCss(); }
        else if (ev.name === "redraw") { prev = []; W("\x1b[2J"); }
        else if (ev.name === "focus") {
          await page.evaluate(() => { const e = document.querySelector("textarea, input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit])"); if (e) e.focus(); });
        }
        break;
      case "mouse": {
        if (ev.y > geo.rows) return;
        const x = (ev.x - 0.5) * geo.pxCol, y = (ev.y - 0.5) * geo.pxRow;
        if (ev.b & 64) {
          await page.mouse.move(x, y);
          await page.mouse.wheel({ deltaY: (ev.b & 1 ? 1 : -1) * geo.pxRow * 3 });
        } else if (ev.b & 32) {
          const k = `${ev.x},${ev.y}`;
          if (k !== lastMove) { lastMove = k; await page.mouse.move(x, y); }
        } else if ((ev.b & 3) === 0) {
          await page.mouse.move(x, y);
          if (ev.down) await page.mouse.down(); else await page.mouse.up();
        }
        break;
      }
      default: break;
    }
  };
  process.stdin.on("data", (chunk) => {
    for (const ev of parse(chunk)) {
      queue = queue.then(() => handle(ev)).catch((e) => flash(`[input] ${e.message}`)).then(wake);
    }
  });

  const interval = Math.max(16, Math.round(1000 / opts.fps));
  while (running) {
    const t0 = Date.now();
    try {
      const f = await grab();
      title = f.title;
      present(f.lines);
    } catch (e) {
    }
    await sleepOrWake(Math.max(0, interval - (Date.now() - t0)));
  }
}

main().catch((e) => {
  if (process.stdout.isTTY) process.stdout.write("\x1b[0m\x1b[?25h\x1b[?1049l");
  console.error(e);
  process.exit(1);
});